# Databricks Window Functions — One Notebook per Analytic

This bundle contains **14 Databricks notebooks**, each focusing on a specific window function or analytic pattern.

## Notebooks
1. `01_row_number_dedup.py` — `row_number()` for dedup/top-per-group.
2. `02_rank_topn.py` — `rank()` top-N per customer.
3. `03_dense_rank_topn.py` — `dense_rank()` without gaps.
4. `04_percent_rank.py` — `percent_rank()` relative position.
5. `05_cume_dist.py` — `cume_dist()` cumulative distribution.
6. `06_ntile_buckets.py` — `ntile(4)` quartiles.
7. `07_lag_deltas.py` — `lag()` previous value & deltas.
8. `08_lead_next.py` — `lead()` next value & deltas.
9. `09_first_value_anchor.py` — `first_value()` comparison to first.
10. `10_last_value_anchor.py` — `last_value()` comparison (overall vs so-far frames).
11. `11_nth_value.py` — `nth_value()` (e.g., 3rd most recent).
12. `12_running_total_rows.py` — running total via `rowsBetween`.
13. `13_moving_avg_rows.py` — 3-row moving average.
14. `14_time_range_moving_avg.py` — 7-day trailing average via `rangeBetween`.

## Data
- `data/daily_sales.csv`
- `data/orders.csv`
- `data/products.csv`

## Use on Databricks
1. Import the notebooks (Workspace → Import → Upload files).
2. Upload the CSV files to DBFS path `/FileStore/window_functions` (Data → DBFS → Upload).
3. Run any notebook. Each uses the common paths defined at the top.
