# Databricks notebook source
%md
# 09 — first_value(): Compare each order to the first order per customer

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
w = Window.partitionBy("customer_id").orderBy("order_date")           .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
fv = orders.withColumn("first_amt", first("amount").over(w))            .withColumn("delta_from_first", col("amount") - col("first_amt"))
display(fv.orderBy("customer_id","order_date"))

