# Databricks notebook source
%md
# 11 — nth_value(): 3rd most recent order amount per customer

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
w = Window.partitionBy("customer_id").orderBy(col("order_date").desc())           .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
nth3 = orders.withColumn("third_most_recent_amt", nth_value("amount", 3).over(w))
display(nth3.orderBy("customer_id","order_date", ascending=[True, False]))

