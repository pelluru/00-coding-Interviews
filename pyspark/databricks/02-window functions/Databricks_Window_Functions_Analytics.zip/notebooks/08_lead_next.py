# Databricks notebook source
%md
# 08 — lead(): Next order amount & forward delta per customer

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
w = Window.partitionBy("customer_id").orderBy("order_date")
lead_amt = orders.withColumn("next_amount", lead("amount", 1).over(w))                  .withColumn("forward_delta", col("next_amount") - col("amount"))
display(lead_amt.orderBy("customer_id","order_date"))

