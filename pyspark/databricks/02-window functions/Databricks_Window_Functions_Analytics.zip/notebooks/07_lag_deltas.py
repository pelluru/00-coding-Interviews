# Databricks notebook source
%md
# 07 — lag(): Previous order amount & delta per customer (by date)

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
w = Window.partitionBy("customer_id").orderBy("order_date")
lag_amt = orders.withColumn("prev_amount", lag("amount", 1).over(w))                 .withColumn("delta", col("amount") - col("prev_amount"))
display(lag_amt.orderBy("customer_id","order_date"))

