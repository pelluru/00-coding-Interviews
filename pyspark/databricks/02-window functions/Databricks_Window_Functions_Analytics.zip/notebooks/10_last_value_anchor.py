# Databricks notebook source
%md
# 10 — last_value(): Overall last vs last-so-far per customer

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
w_final = Window.partitionBy("customer_id").orderBy("order_date")                 .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
lv_final = orders.withColumn("last_amt_overall", last("amount").over(w_final))

w_sofar = Window.partitionBy("customer_id").orderBy("order_date")                .rowsBetween(Window.unboundedPreceding, 0)
lv_sofar = orders.withColumn("last_amt_so_far", last("amount").over(w_sofar))

display(lv_final.orderBy("customer_id","order_date"))
display(lv_sofar.orderBy("customer_id","order_date"))

