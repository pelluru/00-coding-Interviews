# Databricks notebook source
%md
# 03 — dense_rank(): Dense ranking of order amounts per customer

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
w = Window.partitionBy("customer_id").orderBy(col("amount").desc())
dr = orders.withColumn("dense_rank", dense_rank().over(w))
display(dr.orderBy("customer_id","dense_rank"))

