# Databricks notebook source
%md
# 14 — Time-Range Moving Average (rangeBetween): 7-day trailing average per customer

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
orders_days = orders.withColumn("order_days", col("order_date").cast("long"))
w = Window.partitionBy("customer_id").orderBy("order_days").rangeBetween(-7, 0)
mov7 = orders_days.withColumn("moving_avg_7d", avg("amount").over(w))
display(mov7.select("customer_id","order_date","amount","moving_avg_7d").orderBy("customer_id","order_date"))

