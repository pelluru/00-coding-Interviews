# Databricks notebook source
%md
# 01 — row_number(): Deduplicate orders per customer by amount (top per day)

# COMMAND ----------
from pyspark.sql.functions import *
from pyspark.sql.window import Window

DATA_BASE = "/FileStore/window_functions"
DAILY_SALES = f"{DATA_BASE}/daily_sales.csv"
ORDERS = f"{DATA_BASE}/orders.csv"
PRODUCTS = f"{DATA_BASE}/products.csv"

daily_sales = (spark.read.options(header=True, inferSchema=True).csv(DAILY_SALES)
               .withColumn("day", to_date("day")))
orders = (spark.read.options(header=True, inferSchema=True).csv(ORDERS)
          .withColumn("order_date", to_date("order_date")))
products = spark.read.options(header=True, inferSchema=True).csv(PRODUCTS)
w = Window.partitionBy("customer_id","order_date").orderBy(col("amount").desc())
rn = orders.withColumn("rn", row_number().over(w))
dedup = rn.filter(col("rn")==1)
display(rn.orderBy("customer_id","order_date","rn"))
display(dedup.orderBy("customer_id","order_date"))

