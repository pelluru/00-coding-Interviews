# Databricks notebook source
%md
# 11 — BROADCAST Hint (optimization example)

Not a join *type*, but a useful SQL hint to force a broadcast hash join.

# COMMAND ----------
%sql
-- Bootstrap: create temp views from CSVs in DBFS
CREATE OR REPLACE TEMP VIEW customers
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/customers.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW orders
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/orders.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW order_items
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/order_items.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW products
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/products.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW categories
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/categories.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW regions
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/regions.csv', header 'true', inferSchema 'true');

# COMMAND ----------
%sql
-- Broadcast the small 'regions' table while joining with customers
SELECT /*+ BROADCAST(r) */ c.customer_id, c.name, r.region_name
FROM customers c
LEFT JOIN regions r
  ON c.region_id = r.region_id
ORDER BY c.customer_id;

