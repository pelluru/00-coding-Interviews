# Databricks notebook source
%md
# 04 — FULL OUTER JOIN (orders ↔ order_items)

Shows unmatched rows on both sides (e.g., O005 appears from order_items; O004 from orders).

# COMMAND ----------
%sql
-- Bootstrap: create temp views from CSVs in DBFS
CREATE OR REPLACE TEMP VIEW customers
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/customers.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW orders
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/orders.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW order_items
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/order_items.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW products
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/products.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW categories
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/categories.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW regions
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/regions.csv', header 'true', inferSchema 'true');

# COMMAND ----------
%sql
SELECT o.order_id, o.customer_id, oi.product_id, oi.qty, oi.unit_price
FROM orders o
FULL OUTER JOIN order_items oi
  ON o.order_id = oi.order_id
ORDER BY o.order_id, oi.order_id;

