# Databricks notebook source
%md
# 03 — RIGHT OUTER JOIN (customers ↔ orders)

Keeps all orders; customer fields are NULL when no match (e.g., order O004).

# COMMAND ----------
%sql
-- Bootstrap: create temp views from CSVs in DBFS
CREATE OR REPLACE TEMP VIEW customers
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/customers.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW orders
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/orders.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW order_items
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/order_items.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW products
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/products.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW categories
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/categories.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW regions
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/regions.csv', header 'true', inferSchema 'true');

# COMMAND ----------
%sql
SELECT c.customer_id, c.name, o.order_id, o.order_date, o.amount
FROM customers c
RIGHT OUTER JOIN orders o
  ON c.customer_id = o.customer_id
ORDER BY o.order_id;

