# Databricks notebook source
%md
# 07 — CROSS JOIN (products × categories)

Cartesian product of both tables; use with care.

# COMMAND ----------
%sql
-- Bootstrap: create temp views from CSVs in DBFS
CREATE OR REPLACE TEMP VIEW customers
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/customers.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW orders
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/orders.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW order_items
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/order_items.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW products
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/products.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW categories
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/categories.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW regions
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/regions.csv', header 'true', inferSchema 'true');

# COMMAND ----------
%sql
SELECT p.product_id, p.product, c.category_id, c.category_name
FROM products p
CROSS JOIN categories c
ORDER BY p.product_id, c.category_id;

