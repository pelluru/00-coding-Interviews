# Databricks notebook source
%md
# 06 — LEFT ANTI JOIN (customers without orders)

Returns rows from left side with **no** match on right (e.g., customer 103).

# COMMAND ----------
%sql
-- Bootstrap: create temp views from CSVs in DBFS
CREATE OR REPLACE TEMP VIEW customers
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/customers.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW orders
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/orders.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW order_items
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/order_items.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW products
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/products.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW categories
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/categories.csv', header 'true', inferSchema 'true');

CREATE OR REPLACE TEMP VIEW regions
USING csv
OPTIONS (path 'dbfs:/FileStore/joins/regions.csv', header 'true', inferSchema 'true');

# COMMAND ----------
%sql
SELECT c.*
FROM customers c
LEFT ANTI JOIN orders o
  ON c.customer_id = o.customer_id
ORDER BY c.customer_id;

