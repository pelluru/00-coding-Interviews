# Spark SQL Joins — One Notebook per Join (Databricks)

This bundle includes **Spark SQL notebooks** demonstrating each common join type with **sample CSV data**.

## Notebooks
1. `01_inner_join.py` — INNER JOIN (customers ↔ orders)
2. `02_left_outer_join.py` — LEFT OUTER JOIN
3. `03_right_outer_join.py` — RIGHT OUTER JOIN
4. `04_full_outer_join.py` — FULL OUTER JOIN (orders ↔ order_items)
5. `05_left_semi_join.py` — LEFT SEMI JOIN
6. `06_left_anti_join.py` — LEFT ANTI JOIN
7. `07_cross_join.py` — CROSS JOIN
8. `08_natural_join.py` — NATURAL JOIN (on shared column names)
9. `09_join_using_clause.py` — JOIN ... USING (category_id)
10. `10_self_join.py` — SELF JOIN (orders vs orders)
11. `11_broadcast_join_hint.py` — BROADCAST hint (optimization)

## Sample Data
- `customers.csv`, `orders.csv`, `order_items.csv`, `products.csv`, `categories.csv`, `regions.csv`

## How to Use on Databricks
1. Import the notebooks (Workspace → Import → Upload files).
2. Upload the CSVs to DBFS at `/FileStore/joins` (Data → DBFS → Upload).
3. Open any notebook and **Run All**. The first cell creates temp views for all CSVs.
