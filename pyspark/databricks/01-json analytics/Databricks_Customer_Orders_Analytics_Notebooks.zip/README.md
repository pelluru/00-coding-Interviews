# Customer / Address / Orders — PySpark Analytics (Databricks)

This bundle provides **Databricks notebooks** to analyze nested **Customer → Orders → Items** JSON data.
Each variation is a separate notebook for clarity.

## Data Upload (DBFS)
Upload the sample files to DBFS:
- `dbfs:/FileStore/customer_orders/customers_batch1.json`
- `dbfs:/FileStore/customer_orders/customers_batch2.json`

Create the directory and upload via UI (Data → DBFS → Upload), or use:
```python
dbutils.fs.mkdirs("dbfs:/FileStore/customer_orders")
# Then upload the two JSON files from this bundle's data/ folder.
```

## Notebooks
1. `01_read_and_flatten.py` — Read JSON with explicit schema, flatten address & orders → items.
2. `02_basic_sales_metrics.py` — Customer/order/item totals, revenue, AOV.
3. `03_outer_explode_and_null_safety.py` — Keep customers with no orders (outer explode), null-safe calculations.
4. `04_window_analytics_topn_running.py` — Top-N products per customer, running totals by date.
5. `05_city_state_zip_analytics.py` — Revenue by city/state/zip, distinct customers.
6. `06_time_based_analytics.py` — Daily/weekly revenue, first & latest order per customer.
7. `07_data_quality_checks.py` — Basic expectations: null/negative/empty arrays, bad record counts.
8. `08_sql_view_and_materialize.py` — Temp views and SQL-only analytics examples.
9. `09_pivot_category_features.py` — Category pivot to wide table + per-customer features.
10. `10_udf_cleansing_and_normalization.py` — UDF for product-name normalization + standardized analytics.

All notebooks default to `DATA_BASE = "/FileStore/customer_orders"`.
