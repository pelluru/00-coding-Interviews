# Databricks notebook source
%md
# 05 — City / State / Zip Analytics

# COMMAND ----------
from pyspark.sql.types import *
from pyspark.sql.functions import *

item_struct = StructType([
    StructField("product", StringType(), True),
    StructField("category", StringType(), True),
    StructField("price", DoubleType(), True),
    StructField("qty", IntegerType(), True),
])

order_struct = StructType([
    StructField("order_id", StringType(), True),
    StructField("date", StringType(), True),
    StructField("items", ArrayType(item_struct), True),
])

addr_struct = StructType([
    StructField("street", StringType(), True),
    StructField("city", StringType(), True),
    StructField("state", StringType(), True),
    StructField("zip", StringType(), True),
])

customer_schema = StructType([
    StructField("customer_id", LongType(), True),
    StructField("name", StringType(), True),
    StructField("email", StringType(), True),
    StructField("address", addr_struct, True),
    StructField("orders", ArrayType(order_struct), True),
])

DATA_BASE = "/FileStore/customer_orders"
FILES = [f"{DATA_BASE}/customers_batch1.json", f"{DATA_BASE}/customers_batch2.json"]

def load_customers(file_paths=FILES, multiline=True):
    return (spark.read
            .schema(customer_schema)
            .option("multiLine", multiline)
            .json(file_paths))

def flatten(df):
    base = (df
        .withColumn("street", col("address.street"))
        .withColumn("city", col("address.city"))
        .withColumn("state", col("address.state"))
        .withColumn("zip", col("address.zip"))
        .drop("address"))
    orders = base.withColumn("order", explode(col("orders")))
    oflat = (orders
        .withColumn("order_id", col("order.order_id"))
        .withColumn("order_date", col("order.date"))
        .withColumn("items", col("order.items"))
        .drop("order","orders"))
    items = oflat.withColumn("item", explode(col("items")))
    final_df = (items
        .withColumn("product", col("item.product"))
        .withColumn("category", col("item.category"))
        .withColumn("price", col("item.price"))
        .withColumn("quantity", col("item.qty"))
        .drop("item","items"))
    return final_df

from pyspark.sql.functions import sum as _sum, countDistinct

flat = flatten(load_customers()).withColumn("line_total", col("price") * col("quantity"))

by_city = (flat.groupBy("city")
                .agg(countDistinct("customer_id").alias("distinct_customers"),
                     _sum("line_total").alias("city_revenue"))
                .orderBy(col("city_revenue").desc()))

by_state_zip = (flat.groupBy("state","zip")
                     .agg(countDistinct("customer_id").alias("distinct_customers"),
                          _sum("line_total").alias("revenue"))
                     .orderBy(col("state"), col("revenue").desc()))

display(by_city)
display(by_state_zip)

