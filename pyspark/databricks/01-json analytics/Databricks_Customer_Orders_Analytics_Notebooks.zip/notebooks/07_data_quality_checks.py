# Databricks notebook source
%md
# 07 — Data Quality Checks / Expectations (Lightweight)

# COMMAND ----------
from pyspark.sql.types import *
from pyspark.sql.functions import *

item_struct = StructType([
    StructField("product", StringType(), True),
    StructField("category", StringType(), True),
    StructField("price", DoubleType(), True),
    StructField("qty", IntegerType(), True),
])

order_struct = StructType([
    StructField("order_id", StringType(), True),
    StructField("date", StringType(), True),
    StructField("items", ArrayType(item_struct), True),
])

addr_struct = StructType([
    StructField("street", StringType(), True),
    StructField("city", StringType(), True),
    StructField("state", StringType(), True),
    StructField("zip", StringType(), True),
])

customer_schema = StructType([
    StructField("customer_id", LongType(), True),
    StructField("name", StringType(), True),
    StructField("email", StringType(), True),
    StructField("address", addr_struct, True),
    StructField("orders", ArrayType(order_struct), True),
])

DATA_BASE = "/FileStore/customer_orders"
FILES = [f"{DATA_BASE}/customers_batch1.json", f"{DATA_BASE}/customers_batch2.json"]

def load_customers(file_paths=FILES, multiline=True):
    return (spark.read
            .schema(customer_schema)
            .option("multiLine", multiline)
            .json(file_paths))

def flatten(df):
    base = (df
        .withColumn("street", col("address.street"))
        .withColumn("city", col("address.city"))
        .withColumn("state", col("address.state"))
        .withColumn("zip", col("address.zip"))
        .drop("address"))
    orders = base.withColumn("order", explode(col("orders")))
    oflat = (orders
        .withColumn("order_id", col("order.order_id"))
        .withColumn("order_date", col("order.date"))
        .withColumn("items", col("order.items"))
        .drop("order","orders"))
    items = oflat.withColumn("item", explode(col("items")))
    final_df = (items
        .withColumn("product", col("item.product"))
        .withColumn("category", col("item.category"))
        .withColumn("price", col("item.price"))
        .withColumn("quantity", col("item.qty"))
        .drop("item","items"))
    return final_df

from pyspark.sql.functions import size, when, count as _count

df = load_customers()

null_customer_id = df.filter(col("customer_id").isNull()).count()
missing_address = df.filter(col("address").isNull()).count()
empty_orders = df.filter((col("orders").isNull()) | (size(col("orders")) == 0)).count()

flat = flatten(df).withColumn("line_total", col("price")*col("quantity"))
negative_prices = flat.filter(col("price") < 0).count()
negative_qty = flat.filter(col("quantity") < 0).count()

summary = spark.createDataFrame([(
    null_customer_id,
    missing_address,
    empty_orders,
    negative_prices,
    negative_qty
)], ["null_customer_id","missing_address","customers_with_no_orders","negative_prices","negative_qty"])

display(summary)

bad_rows = flat.filter((col("price") < 0) | (col("quantity") < 0) | col("product").isNull())
display(bad_rows.limit(50))

