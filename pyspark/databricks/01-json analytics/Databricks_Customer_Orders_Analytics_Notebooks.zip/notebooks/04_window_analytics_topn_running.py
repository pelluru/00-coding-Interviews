# Databricks notebook source
%md
# 04 — Window Analytics: Top-N Products per Customer & Running Totals by Date

# COMMAND ----------
from pyspark.sql.types import *
from pyspark.sql.functions import *

item_struct = StructType([
    StructField("product", StringType(), True),
    StructField("category", StringType(), True),
    StructField("price", DoubleType(), True),
    StructField("qty", IntegerType(), True),
])

order_struct = StructType([
    StructField("order_id", StringType(), True),
    StructField("date", StringType(), True),
    StructField("items", ArrayType(item_struct), True),
])

addr_struct = StructType([
    StructField("street", StringType(), True),
    StructField("city", StringType(), True),
    StructField("state", StringType(), True),
    StructField("zip", StringType(), True),
])

customer_schema = StructType([
    StructField("customer_id", LongType(), True),
    StructField("name", StringType(), True),
    StructField("email", StringType(), True),
    StructField("address", addr_struct, True),
    StructField("orders", ArrayType(order_struct), True),
])

DATA_BASE = "/FileStore/customer_orders"
FILES = [f"{DATA_BASE}/customers_batch1.json", f"{DATA_BASE}/customers_batch2.json"]

def load_customers(file_paths=FILES, multiline=True):
    return (spark.read
            .schema(customer_schema)
            .option("multiLine", multiline)
            .json(file_paths))

def flatten(df):
    base = (df
        .withColumn("street", col("address.street"))
        .withColumn("city", col("address.city"))
        .withColumn("state", col("address.state"))
        .withColumn("zip", col("address.zip"))
        .drop("address"))
    orders = base.withColumn("order", explode(col("orders")))
    oflat = (orders
        .withColumn("order_id", col("order.order_id"))
        .withColumn("order_date", col("order.date"))
        .withColumn("items", col("order.items"))
        .drop("order","orders"))
    items = oflat.withColumn("item", explode(col("items")))
    final_df = (items
        .withColumn("product", col("item.product"))
        .withColumn("category", col("item.category"))
        .withColumn("price", col("item.price"))
        .withColumn("quantity", col("item.qty"))
        .drop("item","items"))
    return final_df

from pyspark.sql.window import Window
from pyspark.sql.functions import sum as _sum, row_number, to_date

flat = flatten(load_customers())     .withColumn("line_total", col("price") * col("quantity"))     .withColumn("order_dt", to_date("order_date"))

w_run = Window.partitionBy("customer_id").orderBy("order_dt").rowsBetween(Window.unboundedPreceding, 0)
running = (flat.groupBy("customer_id","order_dt")
                .agg(_sum("line_total").alias("daily_revenue"))
                .withColumn("running_revenue", _sum("daily_revenue").over(w_run)))

prod_rev = (flat.groupBy("customer_id","product")
                 .agg(_sum("line_total").alias("revenue")))

w_rank = Window.partitionBy("customer_id").orderBy(col("revenue").desc())
topn = prod_rev.withColumn("rank", row_number().over(w_rank)).filter(col("rank") <= 3)

display(running.orderBy("customer_id","order_dt"))
display(topn.orderBy("customer_id","rank"))

