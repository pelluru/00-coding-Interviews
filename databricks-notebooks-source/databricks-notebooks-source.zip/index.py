# Databricks notebook source
# MAGIC %md
# MAGIC # Advanced PySpark Notebooks — Index
# MAGIC * `streaming.py`
# MAGIC * `performance.py`
# MAGIC * `delta_cdc.py`
# MAGIC * `windows.py`
# COMMAND ----------
print("Open the notebooks listed above inside Databricks after importing the ZIP as Source.")
